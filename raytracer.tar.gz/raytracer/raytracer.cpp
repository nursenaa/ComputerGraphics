#include <iostream>
#include "parser.h"
#include "ppm.h"
#include <cmath>
#include <limits>
using namespace parser;

float float_max = std::numeric_limits<float>::max();
float epsilon ;


//vector operations

Vec3f createVec3f(float x, float y, float z){
	Vec3f v;
	v.x = x;
	v.y = y;
	v.z = z;
	return v;
}

void printVec3f(Vec3f A){
	std::cout << A.x << " " << A.y << " " << A.z << "\n";
}

Vec3f crossProduct(Vec3f A, Vec3f B){
	Vec3f C;
	C.x = A.y * B.z - A.z * B.y;
	C.y = - A.x * B.z + A.z * B.x;
	C.z = A.x * B.y - A.y * B.x;
	return C;
}

float dotProduct(Vec3f A, Vec3f B){
	return A.x * B.x + A.y * B.y + A.z * B.z;
}

Vec3f normalizeVec(Vec3f A){
	float val = sqrt(A.x * A.x +  A.y * A.y +  A.z * A.z);
	A.x /= val;
	A.y /= val;
	A.z /= val;
	return A;
}

Vec3f multiplyScalar(Vec3f A, float val){
	A.x *= val;
	A.y *= val;
	A.z *= val;
	return A;
}

Vec3f multiplyVector(Vec3f A, Vec3f B){
	Vec3f v;
	v.x = A.x * B.x;
	v.y = A.y * B.y;
	v.z = A.z * B.z;
	return v;
}

Vec3f sumVec3f(Vec3f A, Vec3f B){
	A.x += B.x;
	A.y += B.y;
	A.z += B.z;
	return A;
}
Vec3f minusVec3f(Vec3f A, Vec3f B){
	A.x -= B.x;
	A.y -= B.y;
	A.z -= B.z;
	return A;
}

float determinant(Vec3f v1, Vec3f v2, Vec3f v3){
	return v1.x * (v2.y * v3.z - v3.y * v2.z) - v1.y * (v2.x * v3.z - v3.x * v2.z) + v1.z * (v2.x * v3.y - v3.x * v2.y);
}

// problems & assumptions

//- assuming that up and gaze vector are already normalized 
//- assuming that nearplane boundaries are always symmetrical (-4 4 -8 8 )
//- problem: where is (i + 0.5)? we are not getting the center of the pixel


//correct the color if > 255
void colorCorrect(Vec3f& color){
	if(color.x > 255)color.x = 255;
	if(color.y > 255)color.y = 255;
	if(color.z > 255)color.z = 255;
	if(color.x < 0)color.x =0 ;
	if(color.y < 0)color.y =0 ;
	if(color.z < 0)color.z =0 ;
}

float max(float a, float b){
	if(a > b){
	return a;
	}
	return b;
}

float getLength(Vec3f A){
	return sqrt(A.x * A.x +  A.y * A.y +  A.z * A.z);
}




 

//cheks the intersection of ray - object and returns the color of the corresponding pixel


//////////////////7
//////////////////////////
///////////////////////////////77
////////////////

// NEWS!

Vec3f getIntersection(Scene& scene, Material& material, Vec3f& normalvec, Vec3f o, Vec3f d, float& tval){
	// o -> origin of the ray
	// d -> direction of the ray
	// r(t) = o + dt

	Vec3f intersectionPoint ;
	float closeT = float_max;


    //sphere intersection
    for(int i = 0;  i < scene.spheres.size(); i++){
        //compute t
        // (d.d)t^2 + 2d.(o-c)t + (o-c).(o-c) - r^2 = 0

        
        Sphere sphere = scene.spheres[i];
        Vec3f center = scene.vertex_data[sphere.center_vertex_id - 1];
        float r = sphere.radius;


        Vec3f o_c = minusVec3f(o, center);
		float dd = dotProduct(d, d);

        float discriminant = pow(dotProduct(d, o_c),2) - dd * (dotProduct(o_c, o_c) - pow(r,2));
        

        if(discriminant >= 0){ 
			//why not >=? what if only single point of intersection occurs?
        
            //exists an intersection
            discriminant = sqrt(discriminant);
			float t = ( - dotProduct(d, o_c) - discriminant) / dd;
			
            if(t < closeT && t > 0.0f){
				closeT = t;
                material = scene.materials[sphere.material_id - 1];
				intersectionPoint = sumVec3f(o, multiplyScalar(d, t));
				normalvec = normalizeVec(minusVec3f(intersectionPoint, center));
			}
			continue;
        }
    }
	//mesh intersection
    for(int m = 0; m < scene.meshes.size(); m++){
		for(int j = 0; j < scene.meshes[m].faces.size(); j++){

			Face face = scene.meshes[m].faces[j];

			if(face.control==true){					
			}else{
                Vec3f v0 = scene.vertex_data[face.v0_id-1];
				Vec3f v1 = scene.vertex_data[face.v1_id-1];
				Vec3f v2 = scene.vertex_data[face.v2_id-1];

				face.normal = normalizeVec(crossProduct(minusVec3f(v1,v0),minusVec3f(v2,v0)));
				face.A1 = createVec3f(v0.x - v2.x, v0.y - v2.y, v0.z - v2.z);
				face.A2 = createVec3f(v1.x - v2.x, v1.y - v2.y, v1.z - v2.z);
				face.control = true;                    
            }


			if(dotProduct(face.normal, d) > 0){
				continue;
			}

			Vec3f A3 = createVec3f(-d.x,-d.y,-d.z);
			Vec3f J = minusVec3f(o, scene.vertex_data[face.v2_id-1]);

			float detera = determinant(face.A1,face.A2,A3);

			if(detera == 0.0f){ // ONLY IF NO INTERSECTION
				continue;
			}

			float alpha = determinant(J,face.A2,A3) / detera;
			float beta = determinant(face.A1,J,A3) / detera;

			if(alpha < -epsilon || beta < -epsilon || alpha + beta > 1 + epsilon){
				continue;
			}

			float t = determinant(face.A1,face.A2,J) / detera;


			if(t < closeT && t > epsilon){
					closeT = t;
					intersectionPoint = sumVec3f(o, multiplyScalar(d,t));
					normalvec = face.normal;
					material = scene.materials[scene.meshes[m].material_id-1];
		    }
		}
	}

	//triangle intersection!!!!!!

	for(int k = 0; k < scene.triangles.size(); k++){
		Triangle triangle = scene.triangles[k];
		Face face = triangle.indices;
		if(face.control == true){
		}else{
			Vec3f v0 = scene.vertex_data[face.v0_id-1];
			Vec3f v1 = scene.vertex_data[face.v1_id-1];
			Vec3f v2 = scene.vertex_data[face.v2_id-1];
			face.normal = normalizeVec(crossProduct(minusVec3f(v1,v0),minusVec3f(v2,v0)));
			face.A1 = createVec3f(v0.x - v2.x, v0.y - v2.y, v0.z - v2.z);
			face.A2 = createVec3f(v1.x - v2.x, v1.y - v2.y, v1.z - v2.z);
			face.control = true;   
		}

		if(dotProduct(face.normal, d) >= 0){
			continue;
		}
		Vec3f A3 = createVec3f(-d.x,-d.y,-d.z);
		Vec3f J = minusVec3f(o, scene.vertex_data[face.v2_id-1]);
		float detera = determinant(face.A1,face.A2,A3);

		if(detera == 0.0f){ // ONLY IF NO INTERSECTION
			continue;
		}
		float alpha = determinant(J,face.A2,A3) / detera;
		float beta = determinant(face.A1,J,A3) / detera;

		if(alpha < -epsilon || beta < -epsilon || alpha + beta > 1 + epsilon){
			continue;
		}
		float t = determinant(face.A1,face.A2,J) / detera;

		if(t < closeT && t > epsilon){			
			closeT = t;
			intersectionPoint = sumVec3f(o,multiplyScalar(d,t));
			normalvec = face.normal;
			material = scene.materials[scene.triangles[k].material_id-1];
		}

	}
    

	if(closeT != float_max){
		tval = closeT;
		return intersectionPoint;
		
    }else{
		//no intersection case
		// !!caution!! material and normalvec is null here 
		tval = -1;
		Vec3f nullvec ;
		return nullvec;
	}

}

Vec3f getColor(Scene& scene, Vec3f pixelpos, Vec3f d, int recursion, bool& intersects){

	//find intersection of the ray with the closest object
	//using the intersection point and object info compute color

	

	Vec3f color;
	color.x = color.y = color.z = 0;

	if(recursion < 0 ){
		return color;
	}
	

	Vec3f P; //intersection position
	Vec3f N; //normal of the object
	Material material; //material of the object
	float tval = - 1;

	//compute color
	P = getIntersection(scene, material, N, pixelpos, d, tval);
	Vec3f posminuscampos = normalizeVec(minusVec3f(P, pixelpos));

	if(tval != -1){
		//intersection exists
		//use material info to compute color
		intersects = true;
		color = multiplyVector(scene.ambient_light, material.ambient);
		for(int i = 0; i < scene.point_lights.size(); i++){
		// L - P
			PointLight light = scene.point_lights[i];

			//diffuse
			Vec3f ray = minusVec3f(light.position,P);
			Vec3f raydir = normalizeVec(ray);
			float angle = max(0.0f,dotProduct(raydir, N)); //if comes at the back, dotProduct would be negative hence take  0.
			

			if(angle != 0){ //if angle == 0 : light does not contribute to that object
				
				float distance = getLength(ray);

				//if light hits another object before this one: do not contribute to color
				float tval2 = - 1;
				Material dmat;
				Vec3f dnorm;

				Vec3f epsilon_vec = multiplyScalar(N, epsilon);
				Vec3f P2 = sumVec3f(P, epsilon_vec);

				getIntersection(scene, dmat, dnorm, P2, raydir, tval2);

				if(tval2 != -1 && tval2 < distance ){
					//then another object blocks
					//what if this computes the object itself where tval2 = 0? use epsilon?
					continue;
				}
				
				
				color = sumVec3f( color, multiplyScalar(multiplyVector(material.diffuse,light.intensity),angle / pow(distance,2)));

			
				Vec3f halfvector = normalizeVec(minusVec3f(raydir,posminuscampos));
				float angleofspecular = dotProduct(halfvector, N);

				//specular
			
				color = sumVec3f( color, multiplyScalar(multiplyVector(material.specular, light.intensity),pow(angleofspecular, material.phong_exponent) / pow(distance,2)));

			}


		}
	
	}
	else{
		//set to background color
		//no intersection
		intersects = false;
		color = createVec3f(scene.background_color.x,scene.background_color.y,scene.background_color.z);
	}

	if(recursion > 0 && material.is_mirror && intersects){

					Vec3f interm = multiplyScalar(minusVec3f(posminuscampos, multiplyScalar(N, dotProduct(N, posminuscampos))),2.0f);
					Vec3f refdirec = normalizeVec(minusVec3f(interm,posminuscampos));
					bool intersects = false;
					
					Vec3f epsilon_vec = multiplyScalar(N, epsilon);
					Vec3f P2 = sumVec3f(P, epsilon_vec);

					Vec3f refcolor = getColor(scene, P2, refdirec, recursion - 1, intersects);
					//if no intersection do not add
					if(intersects){
						color = sumVec3f( color, multiplyVector(material.mirror, refcolor));
					}
			}	

	colorCorrect(color);
	return color;
}



/////////////////
///////////////////////////
////////////////////////////////
/////////////////////////////////
typedef unsigned char RGB[3];

int main(int argc, char* argv[])
{
    
    // Sample usage for reading an XML scene file
    parser::Scene scene;

    //load scene info
    scene.loadFromXml(argv[1]);


    //proccess image for each camera
    for(int cameraIndex = 0; cameraIndex < scene.cameras.size(); cameraIndex++){
        
        parser::Camera& camera = scene.cameras[cameraIndex];

        //normalize gaze vec? yes 

        int width = camera.image_width;
        int height = camera.image_height;
        float pixel_width = (camera.near_plane.y - camera.near_plane.x)/width;
        float pixel_height = (camera.near_plane.w - camera.near_plane.z)/height;
        Vec3f right = normalizeVec(crossProduct(camera.gaze,camera.up));
        Vec3f pixel_right = multiplyScalar(right, pixel_width);
        Vec3f pixel_down = multiplyScalar(camera.up, pixel_height*-1);
        Vec3f middle = sumVec3f(camera.position, multiplyScalar(normalizeVec(camera.gaze), camera.near_distance));
        Vec3f topleft = sumVec3f(sumVec3f(middle, multiplyScalar(right, camera.near_plane.x)),  multiplyScalar(camera.up,camera.near_plane.w));
        parser::Vec3f campos = camera.position;
		epsilon = scene.shadow_ray_epsilon;
        

        unsigned char* image = new unsigned char [width * height * 3];

        int i = 0;
        for (int y = 0; y < height; ++y)
        {
            for (int x = 0; x < width; ++x)
            {
                //main rt loop
                //1) generate a ray for the corresponding pixel
                //2) find the first object hit by ray and its surface normal n
                //3) set pixel color to value computed from hit point, light, and n 

                // coordinate of the pixel(but this is not middle of the pixel??)
                Vec3f pixelpos = sumVec3f(sumVec3f(topleft, multiplyScalar(pixel_right, x + 0.5)) , multiplyScalar(pixel_down, y + 0.5));;
			    Vec3f dir = normalizeVec(minusVec3f(pixelpos, campos));

                //generate ray
                Ray ray;
                ray.o = pixelpos;
                ray.d = dir; 
				
				bool intersects = false;

				Vec3f color = getColor(scene, pixelpos, dir, scene.max_recursion_depth, intersects );
				
    
                image[i++] = color.x;  //r
                image[i++] = color.y;  //g
                image[i++] = color.z;  //b
            }
        }
        
        write_ppm(scene.cameras[cameraIndex].image_name.c_str(), image, width, height);
    }

    
    
}
